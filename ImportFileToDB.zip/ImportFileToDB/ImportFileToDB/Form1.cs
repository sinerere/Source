﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using CsvHelper;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;

namespace ImportFileToDB
{
    public partial class frmCSV2SQL : Form
    {
        public frmCSV2SQL()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        /// <summary>
        /// This button event is strictly for importing the CSV data to the SQL DB and display it on the datagrid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnImport_Click(object sender, EventArgs e)
        {
            PopulateDatagridview();

            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString))    
            {
                try
                {
                    con.Open();
                    for (int i = 0; i < dgvPersonDetails.Rows.Count; i++)
                    {
                        using (var cmd = new SqlCommand("spInsertUserDetails", con))
                        {
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@Username", dgvPersonDetails.Rows[i].Cells[0].Value.ToString());
                            cmd.Parameters.AddWithValue("@LoginEmail", dgvPersonDetails.Rows[i].Cells[1].Value.ToString());
                            cmd.Parameters.AddWithValue("@UserIdentifier", Convert.ToInt32(dgvPersonDetails.Rows[i].Cells[2].Value.ToString()));
                            cmd.Parameters.AddWithValue("@FirstName", dgvPersonDetails.Rows[i].Cells[3].Value.ToString());
                            cmd.Parameters.AddWithValue("@LastName", dgvPersonDetails.Rows[i].Cells[4].Value.ToString());
                            cmd.Parameters.AddWithValue("@CreatedDate", Convert.ToDateTime(dgvPersonDetails.Rows[i].Cells[5].Value.ToString()));
                            cmd.ExecuteNonQuery();
                        }
                    }                    
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Data was not imported to the database because of the following: " + ex.Message);
                }
            }
        }

        private void PopulateDatagridview()
        {
            if (txtFilePath.Text != string.Empty && Path.GetExtension(txtFilePath.Text) == ".csv")
            {
                List<CSVRows> csvRecords;
                using (var reader = new StreamReader(txtFilePath.Text))
                using (var csvReader = new CsvReader(reader, CultureInfo.InvariantCulture))
                {
                    csvRecords = csvReader.GetRecords<CSVRows>().ToList();
                }
                dgvPersonDetails.DataSource = csvRecords;
            }
            else
                MessageBox.Show("Please select a CSV file to import");
        }

        private void btnBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofdCSV = new OpenFileDialog();
            ofdCSV.ShowDialog();
            txtFilePath.Text = ofdCSV.FileName;
        }

        /// <summary>
        /// This button will open a form that will allow a user to insert a record
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (dgvPersonDetails.Rows.Count > 0)
            {
                frmAddEdit frmAdd = new frmAddEdit(this);
                ControlID.TextData = "Add a Record";

                frmAdd.Show();
            }
            else
                MessageBox.Show("No CSV file has been importet.");
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            if (dgvPersonDetails.SelectedRows.Count > 0)
            {
                if (dgvPersonDetails.SelectedRows.Count == 1)
                {
                    frmAddEdit frmAdd = new frmAddEdit(this);

                    ControlID.TextData = "Edit a Record";
                    ControlID.Username = dgvPersonDetails.SelectedRows[0].Cells[0].Value.ToString();
                    ControlID.Loginemail = dgvPersonDetails.SelectedRows[0].Cells[1].Value.ToString();
                    ControlID.Identifier = dgvPersonDetails.SelectedRows[0].Cells[2].Value.ToString();
                    ControlID.FirstName = dgvPersonDetails.SelectedRows[0].Cells[3].Value.ToString();
                    ControlID.LastName = dgvPersonDetails.SelectedRows[0].Cells[4].Value.ToString();
                    ControlID.Date = dgvPersonDetails.SelectedRows[0].Cells[5].Value.ToString();

                    frmAdd.Show();
                }
                else
                    MessageBox.Show("Selecting more than one row for modifying is prohibited.");
            }
            else
                MessageBox.Show("Please select a row that will be modified.");
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvPersonDetails.SelectedRows.Count > 0)
            {
                if (dgvPersonDetails.SelectedRows.Count == 1)
                {
                    using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString))
                    using (var cmd = new SqlCommand("spRemoveRecord", con))
                    {
                        try
                        {
                            con.Open();
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.Parameters.AddWithValue("@UserIdentifier", Convert.ToInt32(dgvPersonDetails.SelectedRows[0].Cells[2].Value.ToString()));
                            cmd.ExecuteNonQuery();
                            MessageBox.Show("Record has been deleted");

                            List<CSVRows> records = (List<CSVRows>)dgvPersonDetails.DataSource;

                            records.RemoveAt(dgvPersonDetails.SelectedRows[0].Index);
                            
                            dgvPersonDetails.DataSource = records.ToList();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Record was not deleted because: " + ex.Message);
                        }
                    }
                }
                else
                    MessageBox.Show("Selecting more than one row for deleting is prohibited.");
            }
            else
                MessageBox.Show("Please select a row that will be deleted.");
        }
    }
}
