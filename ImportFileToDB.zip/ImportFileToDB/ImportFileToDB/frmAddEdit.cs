﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImportFileToDB
{
    public partial class frmAddEdit : Form
    {
        frmCSV2SQL frmGrid;
        public frmAddEdit(frmCSV2SQL fg)
        {
            InitializeComponent();
            this.frmGrid = fg;
        }
        private void frmAddEdit_Load(object sender, EventArgs e)
        {
            lblAddEditHeader.Text = ControlID.TextData;
            if(lblAddEditHeader.Text == "Edit a Record")
            {
                txtIdentifier.ReadOnly = true;
                txtUsername.Text = ControlID.Username;
                txtEmail.Text = ControlID.Loginemail;
                txtIdentifier.Text = ControlID.Identifier;
                txtName.Text = ControlID.FirstName;
                txtSurname.Text = ControlID.LastName;
                txtDate.Text = ControlID.Date;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string spName;
            string msg;

            if (lblAddEditHeader.Text == "Add a Record")
            {
                spName = "spInsertUserDetails"; 
                msg = "Record has been added.";
                AddEditRecord(spName, msg);
            }
            else
            {
                spName = "spUpdateUserDetails";
                msg = "Record has been updated.";
                AddEditRecord(spName, msg);
            }
        }

        private void AddEditRecord(string spName, string SuccessMessage)
        {
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["dbconnection"].ConnectionString))
            using (var cmd = new SqlCommand(spName, con))
            {
                try
                {
                    con.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Username", txtUsername.Text);
                    cmd.Parameters.AddWithValue("@LoginEmail", txtEmail.Text);
                    cmd.Parameters.AddWithValue("@UserIdentifier", Convert.ToInt32(txtIdentifier.Text));
                    cmd.Parameters.AddWithValue("@FirstName", txtName.Text);
                    cmd.Parameters.AddWithValue("@LastName", txtSurname.Text);
                    cmd.Parameters.AddWithValue("@CreatedDate", Convert.ToDateTime(txtDate.Text));
                    cmd.ExecuteNonQuery();
                    MessageBox.Show(SuccessMessage);

                    if(lblAddEditHeader.Text == "Add a Record")
                    {
                        List<CSVRows> recordNew = (List<CSVRows>)frmGrid.dgvPersonDetails.DataSource;

                        recordNew.Add(new CSVRows()
                        {
                            Username = txtUsername.Text,
                            Loginemail = txtEmail.Text,
                            Identifier = txtIdentifier.Text,
                            FirstName = txtName.Text,
                            LastName = txtSurname.Text,
                            Date = txtDate.Text
                        });

                        frmGrid.dgvPersonDetails.DataSource = recordNew.ToList();
                        frmGrid.Refresh();
                    }
                    else
                    {
                        frmGrid.dgvPersonDetails.SelectedRows[0].Cells[0].Value = txtUsername.Text;
                        frmGrid.dgvPersonDetails.SelectedRows[0].Cells[1].Value = txtEmail.Text;
                        frmGrid.dgvPersonDetails.SelectedRows[0].Cells[2].Value = txtIdentifier.Text;
                        frmGrid.dgvPersonDetails.SelectedRows[0].Cells[3].Value = txtName.Text;
                        frmGrid.dgvPersonDetails.SelectedRows[0].Cells[4].Value = txtSurname.Text;
                        frmGrid.dgvPersonDetails.SelectedRows[0].Cells[5].Value = txtDate.Text;
                    }

                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Data was not imported to the database because of the following: " + ex.Message);
                }
            }
        }
    }
}
