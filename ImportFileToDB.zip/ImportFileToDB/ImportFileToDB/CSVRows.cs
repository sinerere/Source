﻿using CsvHelper.Configuration.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImportFileToDB
{
    public class CSVRows
    {
        public string Username { get; set; }

        [Name("Login email")]
        public string Loginemail { get; set; }
        public string Identifier { get; set; }

        [Name("First name")]
        public string FirstName { get; set; }

        [Name("Last name")]
        public string LastName { get; set; }
        public string Date { get; set; }
    }
}
