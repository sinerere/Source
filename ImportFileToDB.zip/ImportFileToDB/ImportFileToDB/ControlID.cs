﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImportFileToDB
{
    public static class ControlID
    {
        public static string TextData { get; set; }

        public static string Username { get; set; }

        public static string Loginemail { get; set; }
        public static string Identifier { get; set; }

        public static string FirstName { get; set; }

        public static string LastName { get; set; }
        public static string Date { get; set; }
    }
}
